<?php
include("koneksi.php");

// query untuk menampilkan data

$sql = 'SELECT * FROM klinik_312010040';
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title >KLINIK Anisa</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="container">
        <header>
            <h1 align="center">Sistem Informasi Klinik Anisa</h1>
        </header>
      