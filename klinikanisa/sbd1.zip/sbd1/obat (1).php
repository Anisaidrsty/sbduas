<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/bootstrap.min.css" />
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container shadow p-3">
	<header>
	<h2 align="center">Tabel Obat</h2>
	</header>
	<hr>
	<div class="btn-toolbar mb-2 mb-md-10">
		<a href="../data.php" role="button">Kembali</a>
		<a href="obat_tambah.php" role="button"></i>Tambah</a>
	</div>
	<div>
	<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <td>No</td>
				<td>Id Obat</td>
                <td>Nama Obat</td>
				<td>Aksi</td>
            </tr>
        </thead>
        <?php
        require "koneksi.php";
		include "session.php";
        $no = 1;
        $sql = mysqli_query($con, 'SELECT * FROM obat');
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <tr>
                <td><?php echo $no++ ?></td>
				<td><?php echo $data['id_obat'] ?></td>
                <td><?php echo $data['nama_obat'] ?></td>
				<td>
					<a href="obat_ubah.php?id=<?= $data['id_obat'];?>" role="button"><i class="fa-solid fa-pen-to-square"></i></a>
					<a href="obat_hapus.php?id=<?= $data['id_obat'];?>" role="button"><i class="fa-solid fa-trash-can"></i></a>
				</td>
            </tr>
        <?php } ?>
    </table>
	</div>
	</div>
	<hr class="divider">
	<div>
	<div class="card-header">
        <h4>Triger</h4>
    </div>
	<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead">
            <tr>
                <td>No</td>
				<td>Id Log</td>
				<td>Id Obat</td>
                <td>Obat Lama</td>
				<td>Obat Baru</td>
				<td>Waktu</td>
				<td>Aksi</td>
            </tr>
        </thead>
        <?php
        $no = 1;
        $sql = mysqli_query($con, 'SELECT * FROM log_obat');
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <tr>
                <td><?php echo $no++ ?></td>
				<td><?php echo $data['id_log'] ?></td>
				<td><?php echo $data['id_obat'] ?></td>
                <td><?php echo $data['nama_obat_lama'] ?></td>
				<td><?php echo $data['nama_obat_baru'] ?></td>
				<td><?php echo $data['waktu'] ?></td>
				<td><a  href="hapus_triger.php?id=<?= $data['id_log'];?>" role="button"><i class="fa-solid fa-trash-can"></i></a></td>
            </tr>
        <?php } ?>
    </table>
	</div>
	</div>
	<?php require "../footer.php";?>
</div>
</body>
</html>