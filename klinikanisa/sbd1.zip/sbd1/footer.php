<footer>
            <p>&copy; 2022, Anisa Indriani, Klinik_312010040</p>
        </footer>
    </div>
</body>
</html>